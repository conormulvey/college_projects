package com.example.assessment1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        //The area where the user can enter Hexidecimal text, for it to be converted
        final EditText userHexInput = findViewById(R.id.userHexInput);

        //Create an alert when this activity is opened
        AlertDialog sampleTexts = new AlertDialog.Builder(this).create();

        //Given the user a choice of some hexidecimal text, then load it into editText area
        sampleTexts.setMessage("Here are some sample words in Hexdeciaml");
        sampleTexts.setButton(DialogInterface.BUTTON_NEUTRAL, "48656c6c6f20576f726c64",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        userHexInput.setText("48656c6c6f20576f726c64");
                    }
                });

        sampleTexts.setButton(DialogInterface.BUTTON_POSITIVE, "4173736573736d656e74",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        userHexInput.setText("4173736573736d656e74");
                    }
                });

        sampleTexts.setButton(DialogInterface.BUTTON_NEGATIVE, "436f6e6f72",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        userHexInput.setText("436f6e6f72");
                    }
                });

        sampleTexts.show();

        Button convertHexButton  = findViewById(R.id.convertHexButton);
        convertHexButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //first make the input a string
                String hexText = userHexInput.getText().toString();

                //code taken GeeksforGeeks.com
                StringBuilder hex = new StringBuilder();
                for (int i = 0; i < hexText.length(); i+=2) {
                    String str = hexText.substring(i, i+2);
                    hex.append((char)Integer.parseInt(str, 16));
                }

                String res = hex.toString();

                Toast.makeText(getApplicationContext(),hexText+" was converted to "+res,Toast.LENGTH_LONG).show();

                //Send the result back to the first activity, Intro Activity
                openIntro(res);
            }
        });
    }


    //Method for opening intro activity, and sending it teh resulting string from this class
    public void openIntro(String res){
        Intent moveToIntro = new Intent(this, IntroActivity.class);
        moveToIntro.putExtra("hexResult",res);
        startActivity(moveToIntro);
    }

}
