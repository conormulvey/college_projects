package com.example.assessment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class IntroActivity extends AppCompatActivity {

    private EditText userInput;
    private String hexUserInput;
    private static final String FILE_NAME = "stash.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        //Get the text the user entered
        userInput = findViewById(R.id.userInput);

        //Send input to the second activity, MainActivity
        Button convertButton  = findViewById(R.id.convertButton);
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String res = userInput.getText().toString();
                openMain(res);
            }
        });

        //If there is data from another activity avaliable, enter it into the textfield instead
        Bundle hexResult = getIntent().getExtras();
        if (hexResult != null){
            hexUserInput = hexResult.getString("hexResult");
            userInput.setText(hexUserInput);

            //Also if the third activity has taken place, open the NotifActivity
            openNotif();
        }
        else{
            userInput.setText("No input");
        }

        Button hexToTextButton = findViewById(R.id.hexToTextButton);
        hexToTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openThird();
            }
        });

    }

    //Method for opening main activity
    public void openMain(String res){
        Intent moveToMain = new Intent(this, MainActivity.class);
        moveToMain.putExtra("result",res);

        Toast.makeText(getApplicationContext(),res+" has been sent to the second activity",Toast.LENGTH_LONG).show();

        startActivity(moveToMain);
    }

    public void openNotif(){
        Intent moveToNotif = new Intent(this, Notif.class);
        startActivity(moveToNotif);
    }

    public void openThird(){
        Intent moveToThird = new Intent(this, ThirdActivity.class);
        startActivity(moveToThird);
    }

    public void saved (View v){
        String text = userInput.getText().toString();
        FileOutputStream out = null;


        try {
             out = openFileOutput(FILE_NAME, MODE_PRIVATE);
             out.write(text.getBytes());

             Toast.makeText(this,"File saved to "+getFilesDir()+"/"+FILE_NAME, Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if (out!=null){
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void loaded (View v){
        FileInputStream in = null;

        try {
            in = openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(in);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;

            while ((text = br.readLine()) != null){
                sb.append(text).append("\n");

                userInput.setText(sb.toString());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if (in != null){
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
