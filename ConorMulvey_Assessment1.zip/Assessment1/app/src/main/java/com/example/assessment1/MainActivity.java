package com.example.assessment1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView resultArea;
    private String userInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //We recieve the data sent from IntroActivity as userInput
        Bundle getResult = getIntent().getExtras();
        if (getResult != null){
            userInput = getResult.getString("result");
        }

        //We sent te text in the view field as what ever the user entered
        resultArea = findViewById(R.id.resultArea);
        resultArea.setText(userInput);

        Button singleButton = findViewById(R.id.singleLineButton);
        //when the convertButton is clicked
        singleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //whatever the user types into the userText area will be used as the arg for ASCIItoHEX
                String result = ASCIItoHEX(userInput);
                //send this result to the resultArea
                resultArea.setText(result);

                Toast.makeText(getApplicationContext(),userInput+" was converted to "+result,Toast.LENGTH_LONG).show();

            }
        });

        Button spacedButton = findViewById(R.id.spacedButton);
        spacedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //whatever the user types into the userText area will be used as the arg for ASCIItoHEXspaces
                String result = ASCIItoHEXspaces(userInput);
                //send this result to the resultArea
                resultArea.setText(result);

                Toast.makeText(getApplicationContext(),userInput+" was converted to "+result,Toast.LENGTH_LONG).show();

            }
        });

        Button prefixButton = findViewById(R.id.prefixButton);
        prefixButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //whatever the user types into the userText area will be used as the arg for ASCIItoHEXprefix
                String result = ASCIItoHEXprefix(userInput);
                //send this result to the resultArea
                resultArea.setText(result);

                Toast.makeText(getApplicationContext(),userInput+" was converted to "+result,Toast.LENGTH_LONG).show();
            }
        });


    }

    //This method was taken from GeeksForGeeks.com
    public static String ASCIItoHEX(String ascii)
    {
        // Initialize final String
        String hex = "";

        // Make a loop to iterate through
        // every character of ascii string
        for (int i = 0; i < ascii.length(); i++) {

            // take a char from
            // position i of string
            char ch = ascii.charAt(i);

            // cast char to integer and
            // find its ascii value
            int in = (int)ch;

            // change this ascii value
            // integer to hexadecimal value
            String part = Integer.toHexString(in);

            // add this hexadecimal value
            // to final string.
            hex += part;
        }
        // return the final string hex
        return hex;
    }

    //this method is the same as before only adds a space to result
    public static String ASCIItoHEXspaces(String ascii)
    {
        // Initialize final String
        String hex = "";

        // Make a loop to iterate through
        // every character of ascii string
        for (int i = 0; i < ascii.length(); i++) {

            // take a char from
            // position i of string
            char ch = ascii.charAt(i);

            // cast char to integer and
            // find its ascii value
            int in = (int)ch;

            // change this ascii value
            // integer to hexadecimal value
            String part = Integer.toHexString(in);

            // add this hexadecimal value
            // to final string.
            hex = hex+" "+part;
        }
        // return the final string hex
        return hex;
    }

    //this method is the same as the previous but adds a /x prefix to the string
    public static String ASCIItoHEXprefix(String ascii)
    {
        // Initialize final String
        String hex = "";

        // Make a loop to iterate through
        // every character of ascii string
        for (int i = 0; i < ascii.length(); i++) {

            // take a char from
            // position i of string
            char ch = ascii.charAt(i);

            // cast char to integer and
            // find its ascii value
            int in = (int)ch;

            // change this ascii value
            // integer to hexadecimal value
            String part = Integer.toHexString(in);

            // add this hexadecimal value
            // to final string.
            hex = hex+"/x"+part;
        }
        // return the final string hex
        return hex;
    }

    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putString("input",userInput);

        Toast.makeText(getApplicationContext(),userInput+" has been saved",Toast.LENGTH_LONG).show();
    }

    protected void onRestoreInstanceState(Bundle savedInstatnceState){
        super.onSaveInstanceState(savedInstatnceState);
        userInput = savedInstatnceState.getString("input");
    }



}
