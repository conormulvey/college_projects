package com.example.assessment1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Notif extends AppCompatActivity {
    private Button btnShow, btnClear;
    private NotificationManager manager;
    private Notification myNotication;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notif);

        manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        btnShow = findViewById(R.id.btnShow);
        btnClear = findViewById(R.id.btnClear);

        btnShow.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("021 0000000"));

                PendingIntent pendingIntent = PendingIntent.getActivity(Notif.this, 1, intent, 0);

                Notification.Builder builder = new Notification.Builder(Notif.this);

                builder.setAutoCancel(false);
                builder.setContentTitle("Call Notification");
                builder.setContentText("You can call this number now");
                builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                builder.setContentIntent(pendingIntent);
                builder.setOngoing(true);

                myNotication = builder.getNotification();
                manager.notify(11, myNotication);

            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                manager.cancel(11);
            }
        });
    }
}
