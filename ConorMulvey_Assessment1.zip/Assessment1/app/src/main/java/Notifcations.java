import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

public class Notifcations extends Application {
    public static final String callNotifID = "Call Notification";

    public void onCreate(){
        super.onCreate();

        createNotificationChannel();
    }

    private void createNotificationChannel(){
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel callNotif = new NotificationChannel(
                    callNotifID,
                    "Call Notification",
                    NotificationManager.IMPORTANCE_HIGH
            );
            callNotif.setDescription("This notification will allow you to call a number");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(callNotif);
        }

    }
}


